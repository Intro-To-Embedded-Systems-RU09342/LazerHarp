#ifndef MAIN_H
#define MAIN_H

#include <msp430.h>
#include <stdint.h>

int main(void);
void set_temp(uint8_t temp);

#endif

