/*
 * myGPIO.h
 *
 */

#ifndef LCD_MYGPIO_H_
#define LCD_MYGPIO_H_

// Prototypes
void initGPIO(void);


#endif /* LCD_MYGPIO_H_ */

